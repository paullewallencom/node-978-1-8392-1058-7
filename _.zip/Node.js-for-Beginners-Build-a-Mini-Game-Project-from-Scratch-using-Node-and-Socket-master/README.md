## $5 Tech Unlocked 2021!
[Buy and download this Video for only $5 on PacktPub.com](https://www.packtpub.com/product/node-js-for-beginners-build-a-mini-game-project-from-scratch-using-node-and-socket-video/9781839210587)
-----
*The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

# Node.js-for-Beginners-Build-a-Mini-Game-Project-from-Scratch-using-Node-and-Socket
Code Repository for Node.js for Beginners: Build a Mini Game Project from Scratch using Node and Socket, Published by Packt
